<?php
$content = file_get_contents(__DIR__ . '/../assets/js/facultyData.js');

// Match all objects in javascript array
preg_match_all('/\{\s*id:\s*"([^"]+)",\s*name:\s*"([^"]+)",[^}]+initials:\s*"([^"]+)"\s*\}/s', $content, $matches, PREG_SET_ORDER);

echo "Total faculty found: " . count($matches) . "\n";
foreach ($matches as $m) {
    $id = $m[1];
    $name = $m[2];
    $initials = $m[3];
    
    // Look for partial matches of AP or DY or Patel
    if (stripos($initials, 'AP') !== false || stripos($initials, 'DY') !== false || stripos($name, 'Alpa') !== false || stripos($name, 'Darshana') !== false || stripos($name, 'Patel') !== false) {
        echo "ID: $id | Name: $name | Initials: $initials\n";
    }
}
?>
