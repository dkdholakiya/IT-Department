<?php
$content = file_get_contents(__DIR__ . '/14-07-2026.pdf');

$objects = [];
$offset = 0;
while (preg_match('/(\d+)\s+(\d+)\s+obj\b/s', $content, $m, PREG_OFFSET_CAPTURE, $offset)) {
    $obj_id = intval($m[1][0]);
    $start_pos = $m[0][1];
    
    $end_pos = strpos($content, 'endobj', $start_pos);
    if ($end_pos === false) break;
    
    $obj_content = substr($content, $start_pos, $end_pos + 6 - $start_pos);
    $objects[$obj_id] = $obj_content;
    
    $offset = $end_pos + 6;
}

$pages_kids = [];
foreach ($objects as $id => $obj) {
    if (preg_match('/\/Type\s*\/Pages\b/', $obj)) {
        if (preg_match('/\/Kids\s*\[\s*([^\]]+)\s*\]/', $obj, $m)) {
            preg_match_all('/(\d+)\s+\d+\s+R/', $m[1], $ref_matches);
            foreach ($ref_matches[1] as $kid_id) {
                $pages_kids[] = intval($kid_id);
            }
        }
    }
}

if (empty($pages_kids)) {
    foreach ($objects as $id => $obj) {
        if (preg_match('/\/Type\s*\/Page\b/', $obj) && !preg_match('/\/Type\s*\/Pages\b/', $obj)) {
            $pages_kids[] = $id;
        }
    }
}

$pages_kids = array_values(array_unique($pages_kids));

$out = "";

function extract_text_from_stream($data) {
    $results = [];
    $lines = explode("\n", $data);
    $x = 0; $y = 0;
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        if (preg_match('/([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+Tm/', $line, $m)) {
            $x = floatval($m[5]);
            $y = floatval($m[6]);
        } elseif (preg_match('/^\[(.*)\]\s*TJ/', $line, $m)) {
            $parts = $m[1];
            $str = "";
            $i = 0;
            while ($i < strlen($parts)) {
                if ($parts[$i] == '(') {
                    $i++;
                    $sub = "";
                    while ($i < strlen($parts) && $parts[$i] != ')') {
                        if ($parts[$i] == '\\' && $i + 1 < strlen($parts)) {
                            $sub .= $parts[$i+1];
                            $i += 2;
                        } else {
                            $sub .= $parts[$i];
                            $i++;
                        }
                    }
                    $str .= $sub;
                }
                $i++;
            }
            if (!empty(trim($str))) {
                $results[] = ["x" => $x, "y" => $y, "text" => trim($str)];
            }
        } elseif (preg_match('/^\((.*)\)\s*Tj/', $line, $m)) {
            $str = $m[1];
            $str = str_replace(['\\(', '\\)'], ['(', ')'], $str);
            if (!empty(trim($str))) {
                $results[] = ["x" => $x, "y" => $y, "text" => trim($str)];
            }
        }
    }
    return $results;
}

$page_num = 1;
foreach ($pages_kids as $page_id) {
    $page_obj = $objects[$page_id] ?? '';
    if (empty($page_obj)) continue;
    
    $contents_ids = [];
    if (preg_match('/\/Contents\s*\[\s*([^\]]+)\s*\]/', $page_obj, $m)) {
        preg_match_all('/(\d+)\s+\d+\s+R/', $m[1], $ref_matches);
        foreach ($ref_matches[1] as $c_id) {
            $contents_ids[] = intval($c_id);
        }
    } elseif (preg_match('/\/Contents\s*(\d+)\s+\d+\s+R/', $page_obj, $m)) {
        $contents_ids[] = intval($m[1]);
    }
    
    $out .= "\n=== PAGE $page_num (Object $page_id) ===\n";
    $page_text_items = [];
    
    foreach ($contents_ids as $c_id) {
        $c_obj = $objects[$c_id] ?? '';
        if (empty($c_obj)) continue;
        
        $stream_start = strpos($c_obj, 'stream');
        if ($stream_start === false) continue;
        $stream_start += 6;
        while ($stream_start < strlen($c_obj) && (ord($c_obj[$stream_start]) == 10 || ord($c_obj[$stream_start]) == 13)) {
            $stream_start++;
        }
        
        $stream_end = strpos($c_obj, 'endstream', $stream_start);
        if ($stream_end === false) continue;
        
        $stream_data = substr($c_obj, $stream_start, $stream_end - $stream_start);
        
        $decompressed = @gzuncompress($stream_data);
        if (!$decompressed) {
            $decompressed = @gzinflate($stream_data);
        }
        
        if ($decompressed) {
            $items = extract_text_from_stream($decompressed);
            $page_text_items = array_merge($page_text_items, $items);
        }
    }
    
    $tolerance = 5.0;
    $y_groups = [];
    foreach ($page_text_items as $item) {
        $matched = false;
        foreach ($y_groups as $y_val => &$group) {
            if (abs($y_val - $item["y"]) <= $tolerance) {
                $group[] = $item;
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            $y_groups[$item["y"]] = [$item];
        }
    }
    
    krsort($y_groups);
    
    foreach ($y_groups as $y_val => $group) {
        usort($group, function($a, $b) {
            return $a["x"] <=> $b["x"];
        });
        $out .= sprintf("Y=%.2f: ", $y_val);
        foreach ($group as $item) {
            $out .= sprintf("[%s] (X=%.2f) ", $item["text"], $item["x"]);
        }
        $out .= "\n";
    }
    
    $page_num++;
}

file_put_contents(__DIR__ . '/pages_extracted.txt', $out);
echo "Written to pages_extracted.txt successfully!\n";
?>
