<?php
$content = file_get_contents(__DIR__ . '/14-07-2026.pdf');
preg_match_all('/\/Type\s*\/Page\b/', $content, $matches);
echo "Total Page objects found: " . count($matches[0]) . "\n";

// Let's also check for /Count in /Pages
if (preg_match('/\/Type\s*\/Pages\b.*?\/Count\s*(\d+)/s', $content, $m)) {
    echo "Pages count from Catalog: " . $m[1] . "\n";
}
?>
