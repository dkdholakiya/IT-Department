<?php
// Include the time bases parser logic to get all parsed rows
$content = file_get_contents(__DIR__ . '/14-07-2026.pdf');

$objects = [];
$offset = 0;
while (preg_match('/(\d+)\s+(\d+)\s+obj\b/s', $content, $m, PREG_OFFSET_CAPTURE, $offset)) {
    $obj_id = intval($m[1][0]);
    $start_pos = $m[0][1];
    $end_pos = strpos($content, 'endobj', $start_pos);
    if ($end_pos === false) break;
    $objects[$obj_id] = substr($content, $start_pos, $end_pos + 6 - $start_pos);
    $offset = $end_pos + 6;
}

$pages_kids = [];
foreach ($objects as $id => $obj) {
    if (preg_match('/\/Type\s*\/Pages\b/', $obj)) {
        if (preg_match('/\/Kids\s*\[\s*([^\]]+)\s*\]/', $obj, $m)) {
            preg_match_all('/(\d+)\s+\d+\s+R/', $m[1], $ref_matches);
            foreach ($ref_matches[1] as $kid_id) {
                $pages_kids[] = intval($kid_id);
            }
        }
    }
}
if (empty($pages_kids)) {
    foreach ($objects as $id => $obj) {
        if (preg_match('/\/Type\s*\/Page\b/', $obj) && !preg_match('/\/Type\s*\/Pages\b/', $obj)) {
            $pages_kids[] = $id;
        }
    }
}
$pages_kids = array_values(array_unique($pages_kids));

function extract_text_from_stream($data) {
    $results = [];
    $lines = explode("\n", $data);
    $x = 0; $y = 0;
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        if (preg_match('/([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+Tm/', $line, $m)) {
            $x = floatval($m[5]); $y = floatval($m[6]);
        } elseif (preg_match('/^\[(.*)\]\s*TJ/', $line, $m)) {
            $parts = $m[1]; $str = ""; $i = 0;
            while ($i < strlen($parts)) {
                if ($parts[$i] == '(') {
                    $i++; $sub = "";
                    while ($i < strlen($parts) && $parts[$i] != ')') {
                        if ($parts[$i] == '\\' && $i + 1 < strlen($parts)) {
                            $sub .= $parts[$i+1]; $i += 2;
                        } else {
                            $sub .= $parts[$i]; $i++;
                        }
                    }
                    $str .= $sub;
                }
                $i++;
            }
            if (!empty(trim($str))) $results[] = ["x" => $x, "y" => $y, "text" => trim($str)];
        } elseif (preg_match('/^\((.*)\)\s*Tj/', $line, $m)) {
            $str = $m[1]; $str = str_replace(['\\(', '\\)'], ['(', ')'], $str);
            if (!empty(trim($str))) $results[] = ["x" => $x, "y" => $y, "text" => trim($str)];
        }
    }
    return $results;
}

$all_parsed_rows = [];
$page_num = 1;
foreach ($pages_kids as $page_id) {
    $page_obj = $objects[$page_id] ?? '';
    if (empty($page_obj)) continue;
    
    $contents_ids = [];
    if (preg_match('/\/Contents\s*\[\s*([^\]]+)\s*\]/', $page_obj, $m)) {
        preg_match_all('/(\d+)\s+\d+\s+R/', $m[1], $ref_matches);
        foreach ($ref_matches[1] as $c_id) $contents_ids[] = intval($c_id);
    } elseif (preg_match('/\/Contents\s*(\d+)\s+\d+\s+R/', $page_obj, $m)) {
        $contents_ids[] = intval($m[1]);
    }
    
    $page_text_items = [];
    foreach ($contents_ids as $c_id) {
        $c_obj = $objects[$c_id] ?? '';
        if (empty($c_obj)) continue;
        $stream_start = strpos($c_obj, 'stream');
        if ($stream_start === false) continue;
        $stream_start += 6;
        while ($stream_start < strlen($c_obj) && (ord($c_obj[$stream_start]) == 10 || ord($c_obj[$stream_start]) == 13)) $stream_start++;
        $stream_end = strpos($c_obj, 'endstream', $stream_start);
        if ($stream_end === false) continue;
        $stream_data = substr($c_obj, $stream_start, $stream_end - $stream_start);
        $decompressed = @gzuncompress($stream_data);
        if (!$decompressed) $decompressed = @gzinflate($stream_data);
        if ($decompressed) {
            $items = extract_text_from_stream($decompressed);
            $page_text_items = array_merge($page_text_items, $items);
        }
    }
    
    $base_ys = [];
    foreach ($page_text_items as $item) {
        if ($item["x"] >= 835 && $item["x"] <= 955) {
            if (preg_match('/\b\d{1,2}:\d{2}\b/', $item["text"])) {
                $base_ys[] = $item["y"];
            }
        }
    }
    $base_ys = array_values(array_unique($base_ys));
    usort($base_ys, function($a, $b) { return $b <=> $a; });
    
    $page_rows = [];
    for ($i = 0; $i < count($base_ys); $i++) {
        $base_y = $base_ys[$i];
        $y_min = $base_y - 5.0;
        $y_max = ($i === 0) ? 2100.0 : ($base_ys[$i-1] - 5.0);
        $page_rows[] = [
            "base_y" => $base_y,
            "y_min" => $y_min,
            "y_max" => $y_max,
            "cols" => [
                "DATE" => [], "SR_NO" => [], "ROOM" => [], "SUBJECT" => [], "FACULTY" => [],
                "ALTERATION" => [], "PT" => [], "BRANCH" => [], "SEM" => [], "TIME_IN" => [],
                "TIME_OUT" => [], "REMARKS" => [], "STUDENTS" => []
            ]
        ];
    }
    
    foreach ($page_text_items as $item) {
        if (count($page_rows) > 0 && $item["y"] > $page_rows[0]["y_max"]) continue;
        $target_idx = -1;
        foreach ($page_rows as $idx => $r) {
            if ($item["y"] >= $r["y_min"] && $item["y"] < $r["y_max"]) {
                $target_idx = $idx;
                break;
            }
        }
        if ($target_idx === -1) continue;
        $x = $item["x"]; $text = $item["text"];
        if ($x >= 200 && $x < 310) $page_rows[$target_idx]["cols"]["DATE"][] = $item;
        elseif ($x >= 310 && $x < 365) $page_rows[$target_idx]["cols"]["SR_NO"][] = $item;
        elseif ($x >= 365 && $x < 430) $page_rows[$target_idx]["cols"]["ROOM"][] = $item;
        elseif ($x >= 430 && $x < 515) $page_rows[$target_idx]["cols"]["SUBJECT"][] = $item;
        elseif ($x >= 515 && $x < 575) $page_rows[$target_idx]["cols"]["FACULTY"][] = $item;
        elseif ($x >= 575 && $x < 645) $page_rows[$target_idx]["cols"]["ALTERATION"][] = $item;
        elseif ($x >= 645 && $x < 695) $page_rows[$target_idx]["cols"]["PT"][] = $item;
        elseif ($x >= 695 && $x < 795) $page_rows[$target_idx]["cols"]["BRANCH"][] = $item;
        elseif ($x >= 795 && $x < 835) $page_rows[$target_idx]["cols"]["SEM"][] = $item;
        elseif ($x >= 835 && $x < 895) $page_rows[$target_idx]["cols"]["TIME_IN"][] = $item;
        elseif ($x >= 895 && $x < 955) $page_rows[$target_idx]["cols"]["TIME_OUT"][] = $item;
        elseif ($x >= 955 && $x < 1100) $page_rows[$target_idx]["cols"]["REMARKS"][] = $item;
        elseif ($x >= 1100 && $x < 1210) $page_rows[$target_idx]["cols"]["STUDENTS"][] = $item;
    }
    
    foreach ($page_rows as $r) {
        $row_data = [];
        foreach ($r["cols"] as $col_name => $items_list) {
            usort($items_list, function($a, $b) { return $b["y"] <=> $a["y"]; });
            $texts = array_map(function($it) { return $it["text"]; }, $items_list);
            $joined = preg_replace('/\s+/', ' ', trim(implode(" ", $texts)));
            $row_data[$col_name] = $joined;
        }
        $row_data["PAGE"] = $page_num;
        $all_parsed_rows[] = $row_data;
    }
    $page_num++;
}

// Propagate Date
$current_date = "";
foreach ($all_parsed_rows as &$row) {
    if (!empty($row["DATE"])) {
        $current_date = $row["DATE"];
    } else {
        $row["DATE"] = $current_date;
    }
}

// Branch normalization helper
function normalizeBranch($str) {
    return preg_replace('/[\.\s\-\&]/u', '', strtoupper($str));
}

$ce_branches = [
    normalizeBranch("B TECH COMPUTER ENGINEERING"),
    normalizeBranch("B TECH COMPUTER ENGINEERING CLASS-X"),
    normalizeBranch("B TECH COMPUTER ENGINEERING CLASS-X2"),
    normalizeBranch("B TECH COMPUTER ENGINEERING CLASS-Y1"),
    normalizeBranch("B TECH COMPUTER ENGINEERING CLASS-Y2"),
    normalizeBranch("B TECH COMPUTER ENGINEERING CLASS-B")
];

$it_branches = [
    normalizeBranch("IT CLASS-Z"),
    normalizeBranch("IT CLASS-C")
];

$total_rows = count($all_parsed_rows);
$eligible_ce = 0;
$eligible_it = 0;
$skipped_remarks = 0;

$ce_rows = [];
$it_rows = [];

foreach ($all_parsed_rows as $idx => $r) {
    $norm_branch = normalizeBranch($r["BRANCH"]);
    $is_ce = in_select_list($norm_branch, $ce_branches);
    $is_it = in_select_list($norm_branch, $it_branches);
    
    $has_remark = !empty($r["REMARKS"]) && $r["REMARKS"] !== "---";
    
    if ($is_ce) {
        if ($has_remark) {
            $eligible_ce++;
            $ce_rows[] = $r;
        } else {
            $skipped_remarks++;
        }
    } elseif ($is_it) {
        if ($has_remark) {
            $eligible_it++;
            $it_rows[] = $r;
        } else {
            $skipped_remarks++;
        }
    }
}

function in_select_list($norm, $list) {
    foreach ($list as $item) {
        if (strpos($norm, $item) !== false || strpos($item, $norm) !== false) {
            return true;
        }
    }
    return false;
}

echo "Total Rows: $total_rows\n";
echo "Eligible CE Rows: $eligible_ce\n";
echo "Eligible IT Rows: $eligible_it\n";
echo "Skipped due to Empty Remarks: $skipped_remarks\n\n";

echo "=== CE Rows ===\n";
foreach ($ce_rows as $i => $r) {
    echo "#" . ($i+1) . ": Date={$r['DATE']} Room={$r['ROOM']} Subject={$r['SUBJECT']} Faculty={$r['FACULTY']} Branch={$r['BRANCH']} Time={$r['TIME_IN']}-{$r['TIME_OUT']} Remark={$r['REMARKS']}\n";
}

echo "\n=== IT Rows ===\n";
foreach ($it_rows as $i => $r) {
    echo "#" . ($i+1) . ": Date={$r['DATE']} Room={$r['ROOM']} Subject={$r['SUBJECT']} Faculty={$r['FACULTY']} Branch={$r['BRANCH']} Time={$r['TIME_IN']}-{$r['TIME_OUT']} Remark={$r['REMARKS']}\n";
}
?>
