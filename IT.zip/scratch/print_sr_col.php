<?php
$text = file_get_contents(__DIR__ . '/raw_text.txt');
$lines = explode("\n", $text);

$x = 0; $y = 0;
foreach ($lines as $line) {
    $line = trim($line);
    if (empty($line)) continue;
    
    if (preg_match('/([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+Tm/', $line, $m)) {
        $x = floatval($m[5]);
        $y = floatval($m[6]);
    } elseif (preg_match('/^\[(.*)\]\s*TJ/', $line, $m)) {
        $parts = $m[1];
        $str = "";
        $i = 0;
        while ($i < strlen($parts)) {
            if ($parts[$i] == '(') {
                $i++;
                $sub = "";
                while ($i < strlen($parts) && $parts[$i] != ')') {
                    if ($parts[$i] == '\\' && $i + 1 < strlen($parts)) {
                        $sub .= $parts[$i+1];
                        $i += 2;
                    } else {
                        $sub .= $parts[$i];
                        $i++;
                    }
                }
                $str .= $sub;
            }
            $i++;
        }
        if ($x >= 325 && $x <= 355) {
            echo "X={$x}, Y={$y}, Text='{$str}'\n";
        }
    }
}
?>
