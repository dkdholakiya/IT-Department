<?php
$stringsFile = __DIR__ . '/unzipped_xlsx/xl/sharedStrings.xml';
if (file_exists($stringsFile)) {
    $stringsXML = file_get_contents($stringsFile);
    $xml = simplexml_load_string($stringsXML);
    foreach ($xml->si as $si) {
        $val = "";
        if (isset($si->t)) {
            $val = (string)$si->t;
        } else {
            $parts = [];
            foreach ($si->r as $r) {
                $parts[] = (string)$r->t;
            }
            $val = implode("", $parts);
        }
        if (stripos($val, 'APV') !== false || stripos($val, 'DYV') !== false || stripos($val, 'Alpa') !== false || stripos($val, 'Darshana') !== false || stripos($val, 'Vyas') !== false || stripos($val, 'Patel') !== false) {
            echo "String: $val\n";
        }
    }
} else {
    echo "sharedStrings.xml not found.\n";
}
?>
