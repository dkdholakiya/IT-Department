<?php
$text = file_get_contents(__DIR__ . '/raw_text.txt');

$lines = explode("\n", $text);
$x = 0; $y = 0;
$current_text = "";
$results = [];

foreach ($lines as $line) {
    $line = trim($line);
    if (empty($line)) continue;
    
    if (preg_match('/([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+Tm/', $line, $m)) {
        $x = floatval($m[5]);
        $y = floatval($m[6]);
    } elseif (preg_match('/^\[(.*)\]\s*TJ/', $line, $m)) {
        $parts = $m[1];
        // Parse TJ array, e.g. (D)-5(AT)10(E) or (1)-10(4)
        $str = "";
        $i = 0;
        while ($i < strlen($parts)) {
            if ($parts[$i] == '(') {
                $i++;
                $sub = "";
                while ($i < strlen($parts) && $parts[$i] != ')') {
                    // Handle escaped chars if any
                    if ($parts[$i] == '\\' && $i + 1 < strlen($parts)) {
                        $sub .= $parts[$i+1];
                        $i += 2;
                    } else {
                        $sub .= $parts[$i];
                        $i++;
                    }
                }
                $str .= $sub;
            }
            $i++;
        }
        $results[] = ["x" => $x, "y" => $y, "text" => $str];
    } elseif (preg_match('/^\((.*)\)\s*Tj/', $line, $m)) {
        $str = $m[1];
        // handle escape chars
        $str = str_replace(['\\(', '\\)'], ['(', ')'], $str);
        $results[] = ["x" => $x, "y" => $y, "text" => $str];
    }
}

// Group by Y coordinate (within tolerance) and sort by X coordinate
$tolerance = 5.0;
$y_groups = [];

foreach ($results as $item) {
    $matched = false;
    foreach ($y_groups as $y_val => &$group) {
        if (abs($y_val - $item["y"]) <= $tolerance) {
            $group[] = $item;
            $matched = true;
            break;
        }
    }
    if (!$matched) {
        $y_groups[$item["y"]] = [$item];
    }
}

// Sort Y groups descending (top to bottom)
krsort($y_groups);

foreach ($y_groups as $y_val => $group) {
    // Sort items inside group by X ascending (left to right)
    usort($group, function($a, $b) {
        return $a["x"] <=> $b["x"];
    });
    
    echo sprintf("Y=%.2f: ", $y_val);
    foreach ($group as $item) {
        echo sprintf("[%s] (X=%.2f) ", $item["text"], $item["x"]);
    }
    echo "\n";
}
?>
