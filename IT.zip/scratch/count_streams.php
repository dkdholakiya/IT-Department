<?php
$content = file_get_contents(__DIR__ . '/14-07-2026.pdf');
$pos = 0;
$count = 0;
$success = 0;
while (($pos = strpos($content, 'stream', $pos)) !== false) {
    $count++;
    $pos += 6;
    while ($pos < strlen($content) && (ord($content[$pos]) == 10 || ord($content[$pos]) == 13)) {
        $pos++;
    }
    $endpos = strpos($content, 'endstream', $pos);
    if ($endpos === false) break;
    $stream = substr($content, $pos, $endpos - $pos);
    $pos = $endpos + 9;
    
    $data = @gzuncompress($stream);
    if (!$data) {
        $data = @gzinflate($stream);
    }
    if ($data) {
        $success++;
    }
}
echo "Total streams found: $count, Successfully decompressed: $success\n";
?>
