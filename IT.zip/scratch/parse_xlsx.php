<?php
$unzipDir = __DIR__ . '/unzipped_xlsx';

$sharedStrings = [];
$stringsFile = $unzipDir . '/xl/sharedStrings.xml';
if (file_exists($stringsFile)) {
    $stringsXML = file_get_contents($stringsFile);
    $xml = simplexml_load_string($stringsXML);
    foreach ($xml->si as $si) {
        if (isset($si->t)) {
            $sharedStrings[] = (string)$si->t;
        } else {
            $parts = [];
            foreach ($si->r as $r) {
                $parts[] = (string)$r->t;
            }
            $sharedStrings[] = implode("", $parts);
        }
    }
}

$sheetFile = $unzipDir . '/xl/worksheets/sheet1.xml';
if (file_exists($sheetFile)) {
    $sheetXML = file_get_contents($sheetFile);
    $xml = simplexml_load_string($sheetXML);
    
    $rows = [];
    foreach ($xml->sheetData->row as $row) {
        $r_idx = intval($row['r']);
        $rowData = [];
        foreach ($row->c as $c) {
            $cellRef = (string)$c['r'];
            preg_match('/^[A-Z]+/', $cellRef, $colMatch);
            $col = $colMatch[0];
            
            $val = "";
            if (isset($c->v)) {
                $v = (string)$c->v;
                if (isset($c['t']) && (string)$c['t'] === 's') {
                    $val = $sharedStrings[intval($v)] ?? $v;
                } else {
                    $val = $v;
                }
            }
            $rowData[$col] = $val;
        }
        $rows[$r_idx] = $rowData;
    }
    
    foreach ($rows as $idx => $r) {
        echo "Row $idx: ";
        foreach ($r as $col => $val) {
            echo "$col='$val' | ";
        }
        echo "\n";
    }
} else {
    echo "sheet1.xml not found.\n";
}
?>
