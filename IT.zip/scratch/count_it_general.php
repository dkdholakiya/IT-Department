<?php
// PHP Script to count and list all IT Department classes in the Excel sheet
// This includes both those with and without remarks.

$xlsxPath = __DIR__ . '/14-07-2026.xlsx';
$unzipDir = __DIR__ . '/unzipped_xlsx';

$sharedStrings = [];
$rowsXML = null;

// Helper to load shared strings from XML string/element
function loadSharedStrings($xmlStr) {
    $strings = [];
    $xml = simplexml_load_string($xmlStr);
    if ($xml) {
        foreach ($xml->si as $si) {
            if (isset($si->t)) {
                $strings[] = (string)$si->t;
            } else {
                $parts = [];
                if (isset($si->r)) {
                    foreach ($si->r as $r) {
                        $parts[] = (string)$r->t;
                    }
                }
                $strings[] = implode("", $parts);
            }
        }
    }
    return $strings;
}

// 1. Try to load from ZipArchive first
$loaded = false;
if (class_exists('ZipArchive') && file_exists($xlsxPath)) {
    $zip = new ZipArchive;
    if ($zip->open($xlsxPath) === TRUE) {
        $stringsData = $zip->getFromName('xl/sharedStrings.xml');
        if ($stringsData) {
            $sharedStrings = loadSharedStrings($stringsData);
        }
        $sheetData = $zip->getFromName('xl/worksheets/sheet1.xml');
        if ($sheetData) {
            $rowsXML = simplexml_load_string($sheetData);
            $loaded = true;
        }
        $zip->close();
    }
}

// 2. Fall back to unzipped folder if ZipArchive didn't load it
if (!$loaded) {
    $stringsFile = $unzipDir . '/xl/sharedStrings.xml';
    if (file_exists($stringsFile)) {
        $sharedStrings = loadSharedStrings(file_get_contents($stringsFile));
    }
    $sheetFile = $unzipDir . '/xl/worksheets/sheet1.xml';
    if (file_exists($sheetFile)) {
        $rowsXML = simplexml_load_string(file_get_contents($sheetFile));
        $loaded = true;
    }
}

if (!$loaded || !$rowsXML) {
    die("Error: Could not load sheet1.xml from Excel file or unzipped directory.\n");
}

// Parse sheetData rows
$rawRows = [];
foreach ($rowsXML->sheetData->row as $row) {
    $r_idx = intval($row['r']);
    $rowData = [];
    foreach ($row->c as $c) {
        $cellRef = (string)$c['r'];
        preg_match('/^[A-Z]+/', $cellRef, $colMatch);
        $col = $colMatch[0];
        
        $val = "";
        if (isset($c->v)) {
            $v = (string)$c->v;
            if (isset($c['t']) && (string)$c['t'] === 's') {
                $val = $sharedStrings[intval($v)] ?? $v;
            } else {
                $val = $v;
            }
        }
        $rowData[$col] = $val;
    }
    $rawRows[$r_idx] = $rowData;
}

// Find header row dynamically (containing DATE and SR NO)
$headerIdx = -1;
foreach ($rawRows as $idx => $row) {
    $hasDate = false;
    $hasSrNo = false;
    foreach ($row as $col => $val) {
        $uVal = strtoupper($val);
        if (strpos($uVal, 'DATE') !== false) $hasDate = true;
        if (strpos($uVal, 'SR') !== false || strpos($uVal, 'NO.') !== false) $hasSrNo = true;
    }
    if ($hasDate && $hasSrNo) {
        $headerIdx = $idx;
        break;
    }
}

if ($headerIdx === -1) {
    die("Error: Could not find header row containing DATE and SR NO.\n");
}

$headerRow = $rawRows[$headerIdx];
$colMapping = [
    'date' => '', 'srNo' => '', 'room' => '', 'subject' => '', 'faculty' => '',
    'alteration' => '', 'pt' => '', 'branch' => '', 'semester' => '',
    'timeIn' => '', 'timeOut' => '', 'remarks' => '', 'students' => ''
];

foreach ($headerRow as $col => $val) {
    $hText = strtoupper(trim($val));
    if (strpos($hText, 'DATE') !== false) $colMapping['date'] = $col;
    elseif (strpos($hText, 'SR') !== false || strpos($hText, 'NO.') !== false) $colMapping['srNo'] = $col;
    elseif (strpos($hText, 'CLASS') !== false || strpos($hText, 'LAB') !== false) $colMapping['room'] = $col;
    elseif (strpos($hText, 'SUBJECT') !== false) $colMapping['subject'] = $col;
    elseif (strpos($hText, 'FACULTY') !== false) $colMapping['faculty'] = $col;
    elseif (strpos($hText, 'ALTERATION') !== false) $colMapping['alteration'] = $col;
    elseif (strpos($hText, 'P/T') !== false) $colMapping['pt'] = $col;
    elseif (strpos($hText, 'BRANCH') !== false) $colMapping['branch'] = $col;
    elseif (strpos($hText, 'SEM') !== false) $colMapping['semester'] = $col;
    elseif (strpos($hText, 'TIME IN') !== false) $colMapping['timeIn'] = $col;
    elseif (strpos($hText, 'TIME OUT') !== false) $colMapping['timeOut'] = $col;
    elseif (strpos($hText, 'REMARKS') !== false) $colMapping['remarks'] = $col;
    elseif (strpos($hText, 'STUDENT') !== false) $colMapping['students'] = $col;
}

// Helper to clean and normalize strings
function cleanStr($val) {
    if ($val === null) return "";
    return trim(preg_replace('/[\r\n]+/', ' ', preg_replace('/\s+/', ' ', $val)));
}

function normalizeBranch($str) {
    return preg_replace('/[\.\s\-\&]/u', '', strtoupper($str));
}

// Extract parsed rows
$parsedRows = [];
$currentDate = "";

for ($r = $headerIdx + 1; $r <= max(array_keys($rawRows)); $r++) {
    if (!isset($rawRows[$r])) continue;
    $row = $rawRows[$r];
    
    $srNoVal = isset($colMapping['srNo']) && isset($row[$colMapping['srNo']]) ? cleanStr($row[$colMapping['srNo']]) : "";
    $roomVal = isset($colMapping['room']) && isset($row[$colMapping['room']]) ? cleanStr($row[$colMapping['room']]) : "";
    $subjectVal = isset($colMapping['subject']) && isset($row[$colMapping['subject']]) ? cleanStr($row[$colMapping['subject']]) : "";
    $rawDate = isset($colMapping['date']) && isset($row[$colMapping['date']]) ? cleanStr($row[$colMapping['date']]) : "";
    $facultyInitials = isset($colMapping['faculty']) && isset($row[$colMapping['faculty']]) ? cleanStr($row[$colMapping['faculty']]) : "";
    $ptVal = isset($colMapping['pt']) && isset($row[$colMapping['pt']]) ? cleanStr($row[$colMapping['pt']]) : "";
    $branchVal = isset($colMapping['branch']) && isset($row[$colMapping['branch']]) ? cleanStr($row[$colMapping['branch']]) : "";
    $semVal = isset($colMapping['semester']) && isset($row[$colMapping['semester']]) ? cleanStr($row[$colMapping['semester']]) : "";
    $timeInVal = isset($colMapping['timeIn']) && isset($row[$colMapping['timeIn']]) ? cleanStr($row[$colMapping['timeIn']]) : "";
    $timeOutVal = isset($colMapping['timeOut']) && isset($row[$colMapping['timeOut']]) ? cleanStr($row[$colMapping['timeOut']]) : "";
    $remarksVal = isset($colMapping['remarks']) && isset($row[$colMapping['remarks']]) ? cleanStr($row[$colMapping['remarks']]) : "";
    $studentsVal = isset($colMapping['students']) && isset($row[$colMapping['students']]) ? cleanStr($row[$colMapping['students']]) : "";

    if (empty($srNoVal) && empty($roomVal) && empty($subjectVal)) {
        continue;
    }

    if (!empty($rawDate)) {
        $currentDate = $rawDate;
    }

    $parsedRows[] = [
        'index' => $r,
        'srNo' => $srNoVal,
        'date' => $currentDate,
        'room' => $roomVal,
        'subject' => $subjectVal,
        'faculty' => $facultyInitials,
        'pt' => $ptVal,
        'branch' => $branchVal,
        'semester' => $semVal,
        'timeIn' => $timeInVal,
        'timeOut' => $timeOutVal,
        'remarks' => $remarksVal,
        'students' => $studentsVal
    ];
}

// Identify IT department rows
$itRowsWithRemarks = [];
$itRowsWithoutRemarks = [];

$itKeywords = ["IT", "INFO", "INFORMATION", "ICT", "INFOMATION"];
$itFalsePositives = [
    "WRITING", "VISITING", "ACTIVITY", "COMMITTEE", "SECURITY", 
    "SUITE", "QUALITY", "AUDIT", "POSITION", "CREDIT", "LIMIT", "HERITAGE"
];
$excludedKeywords = [
    "CIVIL", "ELECTRICAL", "MECH", "MECHANICAL", "CHEM", "CHEMICAL", "PHYSICS", 
    "MATH", "HUMANITIES", "ADMIN", "LOBBY", "SUPERVISION"
];

foreach ($parsedRows as $row) {
    $cleanBranch = normalizeBranch($row['branch']);
    if (empty($cleanBranch)) continue;

    // Check excluded general department keywords
    $isExcluded = false;
    foreach ($excludedKeywords as $word) {
        if (strpos($cleanBranch, $word) !== false) {
            $isExcluded = true;
            break;
        }
    }
    if ($isExcluded) continue;

    // Check IT keywords match
    $branchMatches = false;
    foreach ($itKeywords as $keyword) {
        if ($keyword === "IT") {
            if (strpos($cleanBranch, "IT") !== false) {
                $hasFalsePositive = false;
                foreach ($itFalsePositives as $fp) {
                    if (strpos($cleanBranch, $fp) !== false) {
                        $hasFalsePositive = true;
                        break;
                    }
                }
                if (!$hasFalsePositive) {
                    $branchMatches = true;
                    break;
                }
            }
        } else {
            if (strpos($cleanBranch, $keyword) !== false) {
                $branchMatches = true;
                break;
            }
        }
    }

    if ($branchMatches) {
        $hasRemark = !empty($row['remarks']) && trim($row['remarks']) !== "" && trim($row['remarks']) !== "---";
        if ($hasRemark) {
            $itRowsWithRemarks[] = $row;
        } else {
            $itRowsWithoutRemarks[] = $row;
        }
    }
}

echo "=============================================\n";
echo "       IT DEPARTMENT CLASSES REPORT          \n";
echo "=============================================\n";
echo "Total IT rows with remarks:    " . count($itRowsWithRemarks) . "\n";
echo "Total IT rows without remarks: " . count($itRowsWithoutRemarks) . "\n";
echo "Total IT rows overall:         " . (count($itRowsWithRemarks) + count($itRowsWithoutRemarks)) . "\n";
echo "=============================================\n\n";

echo "--- IT CLASSES WITH REMARKS (" . count($itRowsWithRemarks) . ") ---\n";
foreach ($itRowsWithRemarks as $idx => $r) {
    printf("%2d. SrNo: %-4s | Date: %-11s | Room: %-6s | Subj: %-10s | Fac: %-4s | Branch: %-25s | Remarks: %-15s | Stud: %s\n",
        $idx + 1, $r['srNo'], $r['date'], $r['room'], $r['subject'], $r['faculty'], $r['branch'], $r['remarks'], $r['students']);
}

echo "\n--- IT CLASSES WITHOUT REMARKS (" . count($itRowsWithoutRemarks) . ") ---\n";
foreach ($itRowsWithoutRemarks as $idx => $r) {
    printf("%2d. SrNo: %-4s | Date: %-11s | Room: %-6s | Subj: %-10s | Fac: %-4s | Branch: %-25s | Remarks: %-15s | Stud: %s\n",
        $idx + 1, $r['srNo'], $r['date'], $r['room'], $r['subject'], $r['faculty'], $r['branch'], $r['remarks'] ?: '---', $r['students'] ?: '---');
}

// Print all unique branches in the Excel file
$allUniqueBranches = [];
foreach ($parsedRows as $row) {
    $allUniqueBranches[$row['branch']] = ($allUniqueBranches[$row['branch']] ?? 0) + 1;
}
ksort($allUniqueBranches);

echo "\n=============================================\n";
echo "       ALL UNIQUE BRANCHES IN EXCEL          \n";
echo "=============================================\n";
foreach ($allUniqueBranches as $br => $count) {
    printf("%-50s (Count: %d)\n", $br ?: "[Empty]", $count);
}
?>
