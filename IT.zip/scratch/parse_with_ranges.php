<?php
$text = file_get_contents(__DIR__ . '/raw_text.txt');
$lines = explode("\n", $text);

$x = 0; $y = 0;
$items = [];

foreach ($lines as $line) {
    $line = trim($line);
    if (empty($line)) continue;
    
    if (preg_match('/([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)\s+Tm/', $line, $m)) {
        $x = floatval($m[5]);
        $y = floatval($m[6]);
    } elseif (preg_match('/^\[(.*)\]\s*TJ/', $line, $m)) {
        $parts = $m[1];
        $str = "";
        $i = 0;
        while ($i < strlen($parts)) {
            if ($parts[$i] == '(') {
                $i++;
                $sub = "";
                while ($i < strlen($parts) && $parts[$i] != ')') {
                    if ($parts[$i] == '\\' && $i + 1 < strlen($parts)) {
                        $sub .= $parts[$i+1];
                        $i += 2;
                    } else {
                        $sub .= $parts[$i];
                        $i++;
                    }
                }
                $str .= $sub;
            }
            $i++;
        }
        if (!empty(trim($str))) {
            $items[] = ["x" => $x, "y" => $y, "text" => trim($str)];
        }
    } elseif (preg_match('/^\((.*)\)\s*Tj/', $line, $m)) {
        $str = $m[1];
        $str = str_replace(['\\(', '\\)'], ['(', ')'], $str);
        if (!empty(trim($str))) {
            $items[] = ["x" => $x, "y" => $y, "text" => trim($str)];
        }
    }
}

// Find all SR NOs (items where X is in range [320, 360] and text is an integer)
$sr_items = [];
foreach ($items as $item) {
    if ($item["x"] >= 320 && $item["x"] <= 360 && preg_match('/^\d+$/', $item["text"])) {
        $sr_items[] = [
            "sr" => intval($item["text"]),
            "y" => $item["y"]
        ];
    }
}

// Sort SR items by Y coordinate descending (top to bottom)
usort($sr_items, function($a, $b) {
    return $b["y"] <=> $a["y"];
});

echo "Detected SR NOs:\n";
foreach ($sr_items as $sr) {
    echo "SR: {$sr['sr']} at Y={$sr['y']}\n";
}
echo "\n";

// Define row boundaries
$rows = [];
for ($i = 0; $i < count($sr_items); $i++) {
    $current_sr = $sr_items[$i];
    $next_sr = ($i + 1 < count($sr_items)) ? $sr_items[$i+1] : null;
    
    // Y range for this row
    $y_max = $current_sr["y"] + 10.0; // include elements slightly above the SR number
    $y_min = $next_sr ? ($next_sr["y"] + 10.0) : 200.0; // bottom of table
    
    $rows[] = [
        "sr" => $current_sr["sr"],
        "y_max" => $y_max,
        "y_min" => $y_min,
        "y_sr" => $current_sr["y"],
        "cols" => [
            "DATE" => [],
            "SR_NO" => [$current_sr["sr"]],
            "ROOM" => [],
            "SUBJECT" => [],
            "FACULTY" => [],
            "ALTERATION" => [],
            "PT" => [],
            "BRANCH" => [],
            "SEM" => [],
            "TIME_IN" => [],
            "TIME_OUT" => [],
            "REMARKS" => [],
            "STUDENTS" => []
        ]
    ];
}

// Assign each item on the page to its row and column
foreach ($items as $item) {
    // Skip headers (which sit above the first SR NO)
    if ($item["y"] > $sr_items[0]["y"] + 12.0) {
        continue;
    }
    
    // Find row
    $target_row_idx = -1;
    foreach ($rows as $idx => $r) {
        if ($item["y"] <= $r["y_max"] && $item["y"] > $r["y_min"]) {
            $target_row_idx = $idx;
            break;
        }
    }
    
    if ($target_row_idx === -1) {
        continue;
    }
    
    // Determine column
    $x = $item["x"];
    $text = $item["text"];
    
    if ($x >= 200 && $x < 310) {
        $rows[$target_row_idx]["cols"]["DATE"][] = $text;
    } elseif ($x >= 310 && $x < 365) {
        // Skip adding the SR item again
        if ($text !== strval($rows[$target_row_idx]["sr"])) {
            $rows[$target_row_idx]["cols"]["SR_NO"][] = $text;
        }
    } elseif ($x >= 365 && $x < 430) {
        $rows[$target_row_idx]["cols"]["ROOM"][] = $text;
    } elseif ($x >= 430 && $x < 515) {
        $rows[$target_row_idx]["cols"]["SUBJECT"][] = $text;
    } elseif ($x >= 515 && $x < 575) {
        $rows[$target_row_idx]["cols"]["FACULTY"][] = $text;
    } elseif ($x >= 575 && $x < 645) {
        $rows[$target_row_idx]["cols"]["ALTERATION"][] = $text;
    } elseif ($x >= 645 && $x < 695) {
        $rows[$target_row_idx]["cols"]["PT"][] = $text;
    } elseif ($x >= 695 && $x < 795) {
        $rows[$target_row_idx]["cols"]["BRANCH"][] = $text;
    } elseif ($x >= 795 && $x < 835) {
        $rows[$target_row_idx]["cols"]["SEM"][] = $text;
    } elseif ($x >= 835 && $x < 895) {
        $rows[$target_row_idx]["cols"]["TIME_IN"][] = $text;
    } elseif ($x >= 895 && $x < 955) {
        $rows[$target_row_idx]["cols"]["TIME_OUT"][] = $text;
    } elseif ($x >= 955 && $x < 1100) {
        $rows[$target_row_idx]["cols"]["REMARKS"][] = $text;
    } elseif ($x >= 1100 && $x < 1210) {
        $rows[$target_row_idx]["cols"]["STUDENTS"][] = $text;
    }
}

// Print parsed table
foreach ($rows as $r) {
    echo sprintf(
        "SR=%d | Date=%s | Room=%s | Subject=%s | Faculty=%s | P/T=%s | Branch=%s | Sem=%s | Time=%s-%s | Students=%s | Remarks=%s\n",
        $r["sr"],
        implode(" ", $r["cols"]["DATE"]),
        implode(" ", $r["cols"]["ROOM"]),
        implode(" ", $r["cols"]["SUBJECT"]),
        implode(" ", $r["cols"]["FACULTY"]),
        implode(" ", $r["cols"]["PT"]),
        implode(" ", $r["cols"]["BRANCH"]),
        implode(" ", $r["cols"]["SEM"]),
        implode(" ", $r["cols"]["TIME_IN"]),
        implode(" ", $r["cols"]["TIME_OUT"]),
        implode(" ", $r["cols"]["STUDENTS"]),
        implode(" ", $r["cols"]["REMARKS"])
    );
}
?>
