<?php
function pdf2text($filename) {
    $content = file_get_contents($filename);
    if (!$content) return "Cannot read file";
    
    $texts = [];
    $pos = 0;
    while (($pos = strpos($content, 'stream', $pos)) !== false) {
        $pos += 6;
        while ($pos < strlen($content) && (ord($content[$pos]) == 10 || ord($content[$pos]) == 13)) {
            $pos++;
        }
        $endpos = strpos($content, 'endstream', $pos);
        if ($endpos === false) break;
        
        $stream = substr($content, $pos, $endpos - $pos);
        $pos = $endpos + 9;
        
        $data = @gzuncompress($stream);
        if (!$data) {
            $data = @gzinflate($stream);
        }
        if ($data) {
            // Find all BT ... ET blocks
            $btPos = 0;
            while (($btPos = strpos($data, 'BT', $btPos)) !== false) {
                $etPos = strpos($data, 'ET', $btPos);
                if ($etPos === false) break;
                
                $block = substr($data, $btPos, $etPos - $btPos + 2);
                $texts[] = $block;
                $btPos = $etPos + 2;
            }
        }
    }
    return implode("\n", $texts);
}

$text_dump = pdf2text(__DIR__ . '/14-07-2026.pdf');
echo substr($text_dump, 0, 5000);
file_put_contents(__DIR__ . '/raw_text.txt', $text_dump);
?>
